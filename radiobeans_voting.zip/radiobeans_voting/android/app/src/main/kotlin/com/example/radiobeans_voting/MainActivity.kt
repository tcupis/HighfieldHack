package com.example.radiobeans_voting

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
