import 'package:flutter/material.dart';

final TextStyle strongText = TextStyle(fontWeight: FontWeight.w800, fontSize: 20);